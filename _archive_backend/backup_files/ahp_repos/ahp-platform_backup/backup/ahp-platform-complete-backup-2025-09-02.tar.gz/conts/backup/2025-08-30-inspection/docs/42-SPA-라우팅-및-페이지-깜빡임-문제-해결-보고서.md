# SPA 라우팅 및 페이지 깜빡임 문제 해결 보고서

## 📋 개요

### 문제 상황
- **로컬 서버**: 메인페이지와 서비스 페이지가 번갈아 가며 보이는 깜빡임 현상
- **GitHub Pages**: `aebonlee.github.io/AHP/`에서 메인 페이지가 보였다가 `https://aebonlee.github.io/`로 리다이렉트되는 문제

### 해결 목표
- 페이지 깜빡임 현상 완전 제거
- GitHub Pages SPA 라우팅 안정화
- 사용자 경험 개선

## 🔍 문제 원인 분석

### 1. React.StrictMode로 인한 이중 렌더링
```typescript
// 문제 코드 (src/index.tsx)
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```
- 개발 모드에서 컴포넌트가 두 번 렌더링되어 깜빡임 발생
- useEffect가 두 번 실행되어 상태 변경이 중복 발생

### 2. GitHub Pages SPA 라우팅 미지원
- GitHub Pages는 기본적으로 SPA 라우팅을 지원하지 않음
- `/AHP/` 경로 접근 시 404 오류 발생 후 루트로 리다이렉트
- SPA 라우팅 해결 스크립트 부재

### 3. 비동기 초기화 로직 부재
```typescript
// 문제 코드 - 동기적 초기화
const activateDemoMode = () => {
  // 즉시 상태 변경으로 깜빡임 발생
  setUser(...);
  setActiveTab('personal-service');
};
```

### 4. 홈페이지 URL 설정 오류
```json
// package.json
"homepage": "https://aebonlee.github.io/AHP"  // 마지막 슬래시 누락
```

## 🛠️ 해결 방안

### 1. React.StrictMode 비활성화
```typescript
// 수정 후 (src/index.tsx)
root.render(
  <App />
);
```
- **효과**: 개발 모드 이중 렌더링 방지
- **결과**: 페이지 깜빡임 현상 제거

### 2. GitHub Pages SPA 라우팅 스크립트 추가
```html
<!-- public/index.html -->
<script type="text/javascript">
  // Single Page Apps for GitHub Pages
  (function(l) {
    if (l.search[1] === '/' ) {
      var decoded = l.search.slice(1).split('&').map(function(s) { 
        return s.replace(/~and~/g, '&')
      }).join('?');
      window.history.replaceState(null, null,
          l.pathname.slice(0, -1) + decoded + l.hash
      );
    }
  }(window.location))
</script>
```
- **효과**: SPA 라우팅 문제 해결
- **결과**: GitHub Pages에서 정상적인 페이지 탐색

### 3. 비동기 초기화 로직 개선
```typescript
// 수정 후 (src/App.tsx)
const [isInitializing, setIsInitializing] = useState(true);

const activateDemoMode = async () => {
  console.log('🎯 데모 모드 강제 활성화');
  
  // 초기화 과정 안정화를 위한 지연
  await new Promise(resolve => setTimeout(resolve, 300));
  
  setBackendStatus('unavailable');
  setIsDemoMode(true);
  setUser({...});
  setProjects(DEMO_PROJECTS);
  setSelectedProjectId(DEMO_PROJECTS[0].id);
  setActiveTab('personal-service');
  setIsNavigationReady(true);
};

const initializeApp = async () => {
  setIsInitializing(true);
  
  if (isProduction) {
    await activateDemoMode();
  } else {
    await checkBackendAndInitialize();
  }
  
  setIsInitializing(false);
};
```
- **효과**: 안정적인 초기화 과정
- **결과**: 상태 변경 중 깜빡임 방지

### 4. 초기화 로딩 화면 추가
```typescript
// 초기화 중 로딩 화면
if (isInitializing) {
  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center">
      <div className="text-center text-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
        <h2 className="text-xl font-semibold mb-2">AHP for Paper</h2>
        <p className="text-blue-100">연구 논문을 위한 AHP 의사결정 분석 시스템</p>
        <p className="text-sm text-blue-200 mt-2">시스템을 초기화하고 있습니다...</p>
      </div>
    </div>
  );
}
```
- **효과**: 초기화 중 사용자 경험 개선
- **결과**: 로딩 상태 명확한 표시

### 5. 홈페이지 URL 수정
```json
// package.json
"homepage": "https://aebonlee.github.io/AHP/"  // 마지막 슬래시 추가
```
- **효과**: GitHub Pages 경로 인식 개선
- **결과**: 정확한 기본 경로 설정

## 📊 수정된 파일 목록

### 1. `src/index.tsx`
```diff
- <React.StrictMode>
-   <App />
- </React.StrictMode>
+ <App />
```

### 2. `public/index.html`
```diff
+ <!-- GitHub Pages SPA 라우팅을 위한 스크립트 -->
+ <script type="text/javascript">
+   // SPA 라우팅 스크립트
+ </script>
```

### 3. `src/App.tsx`
```diff
+ const [isInitializing, setIsInitializing] = useState(true);
+ 
+ const initializeApp = async () => {
+   setIsInitializing(true);
+   // 비동기 초기화 로직
+   setIsInitializing(false);
+ };
```

### 4. `package.json`
```diff
- "homepage": "https://aebonlee.github.io/AHP",
+ "homepage": "https://aebonlee.github.io/AHP/",
```

### 5. `public/404.html` (신규 생성)
- GitHub Pages SPA 라우팅을 위한 404 처리 페이지

## ✅ 테스트 결과

### 로컬 개발 서버
- ✅ 페이지 깜빡임 현상 완전 제거
- ✅ 안정적인 초기 로딩
- ✅ 매끄러운 페이지 전환

### GitHub Pages 배포
- ✅ 리다이렉트 문제 해결
- ✅ 직접 URL 접근 가능
- ✅ SPA 라우팅 정상 작동

### 빌드 성능
```
File sizes after gzip:
  266.99 kB (+136 B)  build\static\js\main.8daea7bc.js
  11.59 kB            build\static\css\main.b5b9465e.css
  1.77 kB             build\static\js\453.b108303b.chunk.js
```
- 빌드 성공
- 파일 크기 최적화 유지

## 🔄 배포 가이드

### 1. 로컬 테스트
```bash
npm start
# 브라우저에서 http://localhost:3000 확인
```

### 2. 프로덕션 빌드
```bash
npm run build
# build 폴더 생성 확인
```

### 3. GitHub Pages 배포
```bash
npm run deploy
# gh-pages 브랜치에 자동 배포
```

## 📈 성과 및 개선 효과

### 사용자 경험 개선
- **로딩 시간**: 초기화 로딩 화면으로 명확한 상태 표시
- **안정성**: 페이지 깨짐 현상 완전 제거
- **접근성**: GitHub Pages에서 직접 URL 접근 가능

### 개발자 경험 개선
- **디버깅**: React.StrictMode 제거로 일관된 동작
- **배포**: 안정적인 GitHub Pages 배포
- **유지보수**: 명확한 초기화 로직

### 기술적 안정성
- **라우팅**: SPA 라우팅 완전 지원
- **상태 관리**: 안정적인 상태 초기화
- **성능**: 불필요한 재렌더링 제거

## 🎯 향후 개선 방안

### 1. 라우팅 라이브러리 도입 검토
- React Router 등 전문 라우팅 라이브러리 고려
- 더 복잡한 라우팅 요구사항 대응

### 2. 로딩 상태 관리 개선
- 전역 로딩 상태 관리
- 세밀한 로딩 인디케이터

### 3. 에러 바운더리 추가
- 런타임 에러 처리
- 사용자 친화적 에러 페이지

## 📝 커밋 정보

**커밋 해시**: `7f379f6`
**브랜치**: `main`
**작업일**: 2025-01-19

### 변경된 파일
- `src/index.tsx` - React.StrictMode 제거
- `public/index.html` - SPA 라우팅 스크립트 추가
- `src/App.tsx` - 비동기 초기화 로직 및 로딩 화면 추가
- `package.json` - 홈페이지 URL 수정
- `public/404.html` - GitHub Pages SPA 지원 추가

---

## 결론

이번 수정으로 AHP for Paper 시스템의 주요 사용자 경험 문제들이 해결되었습니다. 로컬 개발 환경과 GitHub Pages 배포 환경 모두에서 안정적이고 매끄러운 페이지 탐색이 가능해졌으며, 사용자들이 혼란 없이 시스템을 이용할 수 있게 되었습니다.